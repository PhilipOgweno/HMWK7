#include <iostream>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

void print_file ( string, ofstream & );
void print_file ( int, ofstream & );
     string uppercase ( string );
