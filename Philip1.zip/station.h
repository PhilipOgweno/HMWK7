#include <iostream>
#include <string>
#include <fstream>

using namespace std;

enum network_code {
    CE, CI, FA, NP, WR
};

enum band_type {
    longperiod, shortperiod, broadband
};

enum instrument_type {
    highgain, lowgain, accelerometer
};

class station
{

public:
    station ();
    void setNetwork_Code (string network_Code);
    void check_network_code ( int, string, ofstream & );
    string network_code_to_string ( network_code );
    string getNetwork_Code ();
    
    void setStn_code (string Stn_code);
    void check_station_code ( int, string, ofstream & );
    network_code string_to_network_code ( string );
    string getStn_Code ();
    
    void setBand_Type (string Band_Type);
    void check_type_of_band ( int, string , ofstream & );
    string band_type_to_string ( band_type );
    string getBand_Type ();
    
    void setInst_Type (string Inst_Type);
    void check_type_of_instrument ( int, string, ofstream & );
    string instrument_type_to_string ( instrument_type );
    instrument_type string_to_instrument_type ( string );
    string getInst_Type ();
    
    void setOrient (string Orient);
    string getOrient ();
    

    private:
    string Network_Code;
    string Stn_Code;
    string Band_Type;
    string Inst_Type;
    string Orient;
};

