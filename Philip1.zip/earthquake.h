#include <iostream>
#include <string>
#include <fstream>

using namespace std;

class earthquake
{

public:
    earthquake ();
    void setEvent_ID (string Event_ID);
    string getEvent_ID ();
    
    void setDate (string  Date);
    void check_date ( string, ofstream & );
    void check_month ( int, ofstream & );
    string monthstring (string & months );
    void check_day ( int, ofstream & );
    void check_year ( int, ofstream & );
    string getDate ();
    
    void setTime_Zone (string & Time_Zone);
    string getTime_zone ();
    void setTime (string & Time);
    void check_time ( string, ofstream & );
    string getTime ();

    void setEqkName (string & EqkName);
    string getEqkName ();
    
    void setLat (string & Lat);
    string getLat ();
    
    void setLon (string & Lon);
    string getLon ();
    
    void setdepth (string & depth);
    string getdepth ();
    
    void setMag_type_string (string & Mag_type_string);
    void check_magnitude_type ( string, ofstream & );
    string getMag_type_string ();
    
    void setMag_size (float Mag_size);
    void check_magnitude_size ( float, ofstream & );
    float getMag_size ();
    
private:
    string Event_ID;
    string Date;
    string Time;
    string Time_Zone;
    string EqkName;
    string Lon;
    string Lat;
    string depth;
    string Mag_type_string;
    float Mag_size;
};
